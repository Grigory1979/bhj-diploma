# HTML-FS-1.1. Задача 1 - Верстка блока с кратким описанием языка HTML

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/LYgEKrr](https://codepen.io/bg21065v/pen/LYgEKrr).

