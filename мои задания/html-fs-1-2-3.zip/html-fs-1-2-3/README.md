# HTML-FS-1-2. Задача 3. Блоки с иллюстрациями для статьи о Нью-Йорке

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/QWZyNYx](https://codepen.io/bg21065v/pen/QWZyNYx).

