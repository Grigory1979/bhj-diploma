# CodePen Home HTML-FS-1.1. Задача 3 - Виджет новой статьи в блоге «Нетологии»

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/RweNzOm](https://codepen.io/bg21065v/pen/RweNzOm).

