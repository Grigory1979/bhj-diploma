# HTML-FS-1-2. Задача №2. Блок с иллюстрацией для статьи о Монреале

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/NWOxNjv](https://codepen.io/bg21065v/pen/NWOxNjv).

