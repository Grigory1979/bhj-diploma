# HTML-FS-1.1. Задача 2 - Стилизация краткого описания статьи для блога «Нетологии»

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/RweNXPX](https://codepen.io/bg21065v/pen/RweNXPX).

