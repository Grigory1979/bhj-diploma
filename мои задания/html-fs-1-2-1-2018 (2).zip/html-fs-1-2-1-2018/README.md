# HTML-FS-1-2. Задача 1. Верстка статьи "Чемпионат мира по футболу 2018" для Википедии

A Pen created on CodePen.io. Original URL: [https://codepen.io/bg21065v/pen/rNqOQON](https://codepen.io/bg21065v/pen/rNqOQON).

